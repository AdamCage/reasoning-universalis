# Reasoning Universalis

**15 ноября 2026: cross-model measurement pilot завершён.** Qwen3-32B и GPT-OSS-20B разметили фиксированные 72 сегмента на 24 task roots; выполнены 194 вызова с двумя техническими пробами, 166 из 192 исследовательских ответов прошли строгую валидацию. На основной hash-выборке согласие с прежним DeepSeek-consensus — 19/43 (44,2%, κ=0,240) для Qwen и 24/43 (55,8%, κ=0,383) для GPT-OSS. Это отрицательный результат переносимости текущего измерителя, без human gold или E0 pass. [Английский research report](reports/CROSS_MODEL_MEASUREMENT_REPORT.md), [трёхстраничный PDF](output/pdf/cross-model-measurement-pilot.pdf), [evidence и run metadata](evidence/cross-model-compat-2026-11-15/manifest.json), [протокол](design/CROSS_MODEL_PROTOCOL_2026_11_15.json) и [дополнение совместимости до первых исследовательских ответов](design/CROSS_MODEL_TRANSPORT_ADDENDUM_2026_11_15.json). Keyless replay: `python scripts/reproduce_cross_model_compat.py`; аудит output contract: `python scripts/audit_cross_model_outputs.py`. Новые обязательства с резервами — **90,63 RUB из отдельно подтверждённых 400**; общий ledger — **2128,95 RUB**. Платный сбор закрыт, не повторять; старые результаты и evidence сохранены.

[Development release — 9 November 2026](releases/DEVELOPMENT_2026_11_09.md): результаты закрытых пилотов, рукописи и переносимый replay без API. Публикация этого пакета сохраняет открытый статус научных гейтов.

**Машинный development-этап завершён 9 ноября по Москве.** [Фиксированный протокол](design/MACHINE_DEVELOPMENT_PROTOCOL_2026_11_08.json) выполнил 1125 вызовов для 200 сегментов S2 на 24 исходных группах задач: 180 функциональных меток consensus, 15 `ambiguous_other`, 5 неразрешённых случаев. [Результат](reports/MACHINE_DEVELOPMENT_RESULT.md), [английская записка](manuscript/MACHINE_DEVELOPMENT_NOTE.md), [технический аудит](reports/MACHINE_VOTE_FAILURE_AUDIT.md). Общий учёт с резервами — **2038,32 RUB из 3300**. API сообщил **14,39 RUB** за новый прогон; это не заменяет сверку биллинга. [Переносимый архив](evidence/machine-annotation-development-2026-11-08/manifest.json) точно воспроизводится без сети на reference CPython3.12.11; команды — в [LOCAL_RESUME.md](LOCAL_RESUME.md). Платный сбор не повторять. Машинное согласие не является человеческим эталоном или оценкой точности естественной разметки; E0 не пройден. Генерации v3 отключены, человеческая разметка отложена.

Фактические квитанции: [воспроизведение](reports/MACHINE_REPRODUCTION_CHECK.md) и [целостность/восстановление EpistemeOS](reports/MACHINE_EPISTEMEOS_CHECK.md). Хеш-проверки подтверждают сохранность артефактов; scientific validity и независимое человеческое review не присваиваются.

**Следующий этап подготовлен offline:** [разбор selection после v2](reports/POST_V2_SELECTION_ANALYSIS.md), [план и неисполняемый кандидат v3](design/POST_V2_NEXT_STAGE_2026_11_08.md), [пакет человеческой E0-разметки](design/E0_HUMAN_DEVELOPMENT_HANDOFF_2026_11_08.md), [English design note](manuscript/POST_V2_DESIGN_NOTE.md). Предварительный v3 содержит 24 новые development-группы и 192 предлагаемые попытки; сбор отключён. Human-пакет содержит 24 exposed roots / 200 S2 segments, пустые формы и ни одной человеческой метки; он не достигает 40-root E0 floor. Закрытые измерения и общий ledger ниже сохраняются, новых расходов нет.

**Development-пилот v2 и однократный recovery R1 завершены 8 ноября.** Проверены 24 новых root-группы при двух лимитах генерации. В объединённом R1-наборе 97 завершённых оцениваемых ответов: 93 верных и четыре ошибки; ещё 95 трасс обрезаны. Общий гейт поддержки классов не пройден; основной сбор и новый test не запускались. [Итог R1](reports/PILOT_V2_RECOVERY_RESULT.md), [исходный A](reports/PILOT_V2_RESULT.md), [протокол](design/PILOT_V2_PROTOCOL_2026_11_08.json), [статистический план](design/PILOT_V2_STATISTICAL_PLAN.md), [английское дополнение к рукописи](manuscript/PILOT_V2_CALIBRATION_NOTE.md). V1 ниже сохраняется как закрытый результат; E0 не пройден.

Все расходы продолжают общий ledger: 823.5589067445220 RUB charged-or-reserved из разрешённых 3000 RUB; это не окончательный биллинг. Самодостаточный пакет `evidence/pilot-v2-recovery-2026-11-08/manifest.json` включает закрытый A и воспроизводится без API через `scripts/reproduce_pilot_v2_recovery.py`. Команды и закрытый статус — в [LOCAL_RESUME.md](LOCAL_RESUME.md).

После измерений Windows CI выявил конфликт чтения и замены ledger в frozen collector. [Отдельный слой совместимости I/O](reports/PILOT_V2_WINDOWS_IO_COMPATIBILITY.md) проверен независимо и предназначен для будущих явно зафиксированных версий; измеренные A/R1 и их исходники сохраняются.

**8 ноября 2026: локальный ограниченный пилот завершён.** Сохранены 384 основные попытки, 333 оцениваемых ответа и четыре ошибки; BGE-M3 и Qwen embedding покрывают по 5778 chunks. Основной вопрос о предсказании ошибок остался неразрешённым из-за нехватки классов. [Результат и ограничения](reports/LOCAL_RESEARCH_RESULT_RU.md), [английская рукопись](manuscript/LOCAL_RESEARCH_PAPER.md), [PDF](output/pdf/local-reasoning-pilot.pdf), [evidence sheet](output/pdf/portfolio-evidence-sheet.pdf). E0 не пройден; H0–H7 не подтверждены.

Платный сбор закрыт. Консервативный charged-or-reserved итог — 651.51803 RUB из разрешённых 3000 RUB, включая исторические обязательства; это не измеренная фактическая оплата. Переносимый архив находится в `evidence/local-pilot-2026-11-08/manifest.json`; [бесплатный offline replay](reports/LOCAL_REPRODUCTION_CHECK.md) восстанавливает исходные bytes и повторяет пять анализов без API. Команды и статус для продолжения — [LOCAL_RESUME.md](LOCAL_RESUME.md).

Состояние предыдущих этапов ниже сохранено для истории. Текущие границы и авторизация — [resumption scope](reports/RESUMPTION_SCOPE_2026_11_08.md); исходные H0–H7 не изменены.

**Этап 3 подготовлен офлайн и не запущен.** Конвейер резервирует ledger до отправки, но оплачиваемый допуск Qwen3-32B и DeepSeek-V4.1-Flash не выполнен. E0 не пройден. План до первого вызова: [STAGE3_PRE_DISPATCH.md](reports/STAGE3_PRE_DISPATCH.md).

Исследование того, какая часть структуры и динамики машинного рассуждения сохраняется при смене модели, а какая задаётся архитектурой, обучением, задачей и способом измерения.

EpistemeOS — ядро доказательств: протоколы, провенанс, эксперименты, статистический вывод и аудит. Корень репозитория — рабочее пространство этого исследования.

## Документы

- [RESEARCH_SPECIFICATION.md](RESEARCH_SPECIFICATION.md) — научная спецификация
- [RESEARCH_PLAN.md](RESEARCH_PLAN.md) — план работ и критерии приёмки этапов
- [literature/README.md](literature/README.md) — обзор литературы этапа 0 спецификации
- [reports/STAGE0_REPORT.md](reports/STAGE0_REPORT.md) — результаты обоих этапов 0, расходы и ограничения
- [stage0/README.md](stage0/README.md) — технический pipeline и команды воспроизведения
- [cursor_objective.md](cursor_objective.md) — рабочий бриф
- [env.example](env.example) — контракт окружения без секрета
- [AGENTS.md](AGENTS.md) — операционные правила агента

## Раскладка

- `EpistemeOS/` — пакет `epistemeos` (Python ≥ 3.11, `uv.lock`)
- `.cursor/environment.json` — установка Cursor Cloud
- `.cursor/rules/research-harness.mdc` — постоянные ограничения харнеса
- `.research/` — локальные артефакты исследования, в git не входят

## Локальный старт

```powershell
copy env.example .env
```

Ключ `ROUTERAI_API_KEY` пишется только в `.env`. Дальше:

```powershell
cd EpistemeOS
uv sync --frozen
```

## Правила агента

Текущее поручение разрешает Codex и программных помощников; исторические ограничения сохранены в [AGENTS.md](AGENTS.md) с пояснением приоритета. Все экспериментальные модельные вызовы учитываются через RouterAI. Секреты и `.env` не публикуются.

## Cursor Cloud

Установка выполняется `bash .cursor/install.sh` из `.cursor/environment.json`. Секрет `ROUTERAI_API_KEY` задаётся во вкладке секретов Cursor Cloud. При старте агента `.cursor/start.sh` собирает из него и из `env.example` локальный `.env`; этот файл в git не попадает.

## Статус

Ревью после PR #8: guards подключены к `stage3/pipeline.py`, контекстный эмбеддинг сверяется по полному входу. Список v2 сохраняет семейную утечку (always-UNSAT 66%). Дополнение v3 — [PILOT_SECTION_5_5_ROSTER_V3.json](design/PILOT_SECTION_5_5_ROSTER_V3.json). Допуск двух новых моделей, E0 и массовый прогон не выполнены.

Этап 2 принят 18 октября 2026: [приёмка](reports/STAGE2_ACCEPTANCE.md), [матрица реализации](reports/STAGE2_REPORT.md), [воспроизведение](stage2/README.md). Standalone DomainPack прошёл kernel workflow на 6 реальных исторических GPT-OSS трассах.

Stage 1: G1 утверждён AdamCage 14 октября 2026 для v1.1, commit `68fc12d`. [Текущая приёмка](reports/STAGE1_ACCEPTANCE.md), [исторический review report](reports/STAGE1_REPORT.md), [preregistration утверждённого пакета](design/PREREGISTRATION_DRAFT.md). Новые вызовы моделей не выполнялись; E0 не пройден, G2 не заморожен.

12 октября 2026 технический Этап 0 выполнен: пробы шести кандидатов и двух эмбеддеров, сохранённые ответы, прогон GPT-OSS-20B на шести задачах (6/6), сегментация и оба эмбеддера. Qwen3-8B недоступен, предложена отдельная замена Qwen3-14B. Литературный Этап 0 принят пользователем по полному препринту Levy с ограничением «журнальная версия не проверена». Подробности — в [отчёте](reports/STAGE0_REPORT.md).

Основное исследование ждёт расширенного научного пилота и замороженного протокола. Технический прогон не заменяет пилот §5.5 и не подтверждает гипотезы.
