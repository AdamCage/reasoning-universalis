"""Complete backup/export of the already closed stage via normal SQLite paths.

The original 98 hash jobs are not rerun. Only closed-stage replay and the
adapter's post-stage metadata/backup export are completed outside frozen code.
"""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from resumption.episteme_adapter import select_kernel, register_pack, advance_stage, canonical


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output = ROOT / ".research/machine-annotation-integrity-stage"
    assert not (output / "stage-result.json").exists()
    assert not (output / "backup").exists()
    provenance = select_kernel(ROOT / ".research/deps/EpistemeOS")
    loaded = register_pack("resumption_evidence_v1", "resumption_evidence_v1")
    from episteme.graph import ResearchGraph
    from episteme.recovery import backup
    from episteme.store import Store
    manifest_bytes = (output / "capture/manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    index_bytes = (ROOT / "artifacts/machine-annotation-development-2026-11-08/evidence-index.json").read_bytes()
    with Store(output / "store") as store:
        stage_ids = [row["id"] for row in store.events() if row["kind"] == "stage_open"]
        assert len(stage_ids) == 1
        before = store.export(), store.export_receipts()
        result = advance_stage(store, stage_ids[0])
        repeated = advance_stage(store, stage_ids[0])
        assert before == (store.export(), store.export_receipts()) and result == repeated
        assert result["status"] == "closed" and result["attempt_ledger"]["completed"] == 98
        assert not any(row["kind"] in {"review_assignment", "review", "paper"} for row in store.events())
        graph = ResearchGraph.from_store(store)
        result.update({"kernel": provenance, "pack_code_digest": loaded.pack_code_digest,
            "evidence_index_sha256": sha(index_bytes), "manifest_sha256": sha(manifest_bytes),
            "artifact_count": len(manifest["artifacts"]), "artifacts": manifest["artifacts"],
            "network_calls": 0, "E0": "not_passed", "closed_stage_replay": "same_history_no_new_attempt",
            "scope": "artifact integrity only; not scientific validity, collection completeness, or preregistration of original experiment",
            "graph_snapshot_hash": graph.snapshot_hash,
            "post_stage_export_compatibility": "Capture used Windows extended-length paths; already closed Store reopened through ordinary path for SQLite URI-compatible backup. No hash job/event/receipt was added."})
        backup(store, output / "backup")
        (output / "events.jsonl").write_text(store.export(), encoding="utf-8", newline="\n")
    (output / "stage-result.json").write_bytes(canonical(result))
    print(json.dumps({"stage": result["stage"], "artifact_count": result["artifact_count"],
        "attempt_ledger": result["attempt_ledger"], "graph_snapshot_hash": result["graph_snapshot_hash"],
        "status": result["status"], "scientific_validity": result["scientific_validity"], "review": result["review"]}))


if __name__ == "__main__":
    main()
