"""Finalize the closed offline mechanical stage; never call a model API."""
from __future__ import annotations
import base64
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path
import re
import sys
from urllib.parse import quote, quote_plus
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from resumption.episteme_adapter import select_kernel
from stage0.config import parse_env


def extended(path):
    path = Path(path).absolute()
    return Path("\\\\?\\" + str(path)) if os.name == "nt" and not str(path).startswith("\\\\?\\") else path


def sha(value):
    return hashlib.sha256(value).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode("utf-8") + b"\n"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def install_new(path, data):
    path = Path(path)
    require(not path.exists(), "Proof output already exists")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def main():
    stage = ROOT / ".research/machine-annotation-integrity-stage"
    restored = ROOT / ".research/machine-annotation-integrity-restored"
    public = ROOT / "artifacts/machine-annotation-development-2026-11-08"
    stage_bytes = (stage / "stage-result.json").read_bytes()
    result = json.loads(stage_bytes)
    require(result["status"] == "closed" and result["disposition"] == "criteria_met"
            and result["outcome"] == "inconclusive" and result["scientific_validity"] == "not_assessed"
            and result["review"] == "not_requested" and result["network_calls"] == 0
            and result["attempt_ledger"]["completed"] == result["roster_size"] == 98
            and result["attempt_ledger"]["failed"] == result["attempt_ledger"]["unknown"] == 0,
            "Integrity stage did not finish its complete bounded mechanical roster")
    kernel = select_kernel(ROOT / ".research/deps/EpistemeOS")
    from episteme.graph import ResearchGraph
    from episteme.recovery import restore
    from episteme.store import Store
    require(not restored.exists(), "Restore path must be fresh")
    with Store(stage / "store", read_only=True) as original:
        events = original.export()
        receipts = original.export_receipts()
        graph = ResearchGraph.from_store(original).snapshot_hash
        event_count, receipt_count = len(original.events()), len(original.receipts())
    require(graph == result["graph_snapshot_hash"], "Closed graph changed before restore")
    restore(stage / "backup", restored)
    with Store(restored, read_only=True) as recovered:
        restored_graph = ResearchGraph.from_store(recovered).snapshot_hash
        require(recovered.export() == events and recovered.export_receipts() == receipts
                and restored_graph == graph, "Backup restore changed events, receipts or graph")
    restored_database_sha = sha((restored / "state.sqlite3").read_bytes())
    require(restored_database_sha == sha((stage / "backup/state.sqlite3").read_bytes()), "Restored database bytes differ")
    for original_blob in (stage / "backup/artifacts").rglob("*"):
        if original_blob.is_file():
            recovered_blob = restored / original_blob.relative_to(stage / "backup")
            require(original_blob.read_bytes() == recovered_blob.read_bytes(), "Restored CAS bytes differ")
    scope = ROOT / ".research/resumption-2026-11-08-live/machine-development/0d53274f64e17249611815abe5bb380f5779818bde5545b5732315127bb1fb5e"
    inventory_path = scope / "source-inventory.json"
    inventory = json.loads(inventory_path.read_bytes())
    source_rows = []
    for name, digest in inventory["files"].items():
        current, captured = (ROOT / name).read_bytes(), (scope / "source" / name).read_bytes()
        require(sha(current) == sha(captured) == digest and current == captured, "Measured source changed")
        source_rows.append({"path": name, "sha256": digest, "current_and_snapshot_exact": True})
    index_bytes = (public / "evidence-index.json").read_bytes()
    for entry in json.loads(index_bytes)["artifacts"]:
        current = (ROOT / entry["path"]).read_bytes()
        require(len(current) == entry["bytes"] and sha(current) == entry["sha256"], "Indexed input changed after capture")
    restore_files = [path for path in restored.rglob("*") if path.is_file()]
    proof = {"schema_version": 1, "backup_restore": "verified",
        "kernel_revision": kernel["revision"], "stage": result["stage"], "artifact_count": result["artifact_count"],
        "attempt_ledger": result["attempt_ledger"], "events": event_count, "receipts": receipt_count,
        "graph_snapshot_hash": graph, "restored_graph_snapshot_hash": restored_graph,
        "exact_event_export_equal": True, "exact_receipt_export_equal": True,
        "event_export_utf8_bytes": len(events.encode("utf-8")), "receipt_export_utf8_bytes": len(receipts.encode("utf-8")),
        "backup_manifest_sha256": sha((stage / "backup/manifest.json").read_bytes()),
        "restored_database_sha256": restored_database_sha, "exact_database_and_CAS_restore_bytes_equal": True,
        "events_jsonl_sha256": sha((stage / "events.jsonl").read_bytes()),
        "stage_result_sha256": sha(stage_bytes), "evidence_index_sha256": sha(index_bytes),
        "restore_files": len(restore_files), "restored_store_bytes": sum(path.stat().st_size for path in restore_files),
        "source_inventory_sha256": sha(inventory_path.read_bytes()), "measured_source_files_exact": len(source_rows),
        "changed_measured_source_files": 0, "source_diff": source_rows,
        "all_indexed_files_unchanged_after_stage": True,
        "first_capture_path_failure": "Windows MAX_PATH before kernel Store/events; preserved partial capture, then fresh extended-length-path stage",
        "post_stage_backup_path_compatibility": "Extended-path SQLite URI export failed after closed stage; same closed Store reopened via normal path, unchanged events/receipts, then backup/export completed",
        "scope": "postcollection byte and graph integrity; same-author hash reanalysis is not independent statistics or scientific review",
        "network_calls": 0, "new_model_calls": 0, "E0": "not_passed", "human_gold": "not_created",
        "scientific_validity": "not_assessed", "review": "not_requested"}
    proof_bytes = canonical(proof)
    install_new(public / "episteme-stage-result.json", stage_bytes)
    install_new(public / "episteme-backup-check.json", proof_bytes)
    configured = parse_env(ROOT / ".env") if (ROOT / ".env").is_file() else {}
    secrets = {value for name, value in list(configured.items()) + list(os.environ.items())
               if value and len(value) >= 8 and re.search(r"(KEY|SECRET|TOKEN|PASSWORD)", name, re.I) and not name.endswith("_TOKENS")}
    def scan(data, nested=0):
        for secret in secrets:
            raw = secret.encode("utf-8")
            variants = (raw, json.dumps(secret)[1:-1].encode(), quote(secret, safe="").encode(),
                        quote_plus(secret).encode(), base64.b64encode(raw), base64.urlsafe_b64encode(raw), raw.hex().encode())
            require(not any(value and value in data for value in variants), "Configured credential detected; value withheld")
        if data.startswith(b"PK\x03\x04") and nested < 4:
            with zipfile.ZipFile(BytesIO(data)) as archive:
                for name in archive.namelist():
                    scan(archive.read(name), nested + 1)
        if data[:1] in (b"{", b"["):
            try:
                value = json.loads(data)
            except ValueError:
                return
            def wrapped(value):
                if isinstance(value, dict):
                    if isinstance(value.get("body_base64"), str):
                        scan(base64.b64decode(value["body_base64"], validate=True), nested + 1)
                    for child in value.values(): wrapped(child)
                elif isinstance(value, list):
                    for child in value: wrapped(child)
            wrapped(value)
    members = {}
    for top in ("backup", "capture"):
        walk_root = extended(stage) if top == "capture" else stage
        for path in (walk_root / top).rglob("*"):
            if path.is_file():
                members[path.relative_to(walk_root).as_posix()] = path.read_bytes()
    for name in ("events.jsonl", "stage-result.json"):
        members[name] = (stage / name).read_bytes()
    members["provenance/episteme-backup-check.json"] = proof_bytes
    members["provenance/finalize-machine-integrity-proof.py"] = Path(__file__).read_bytes()
    members["provenance/finish-machine-stage-export.py"] = (ROOT / ".research/finish_machine_stage_export.py").read_bytes()
    members["provenance/first-capture-path-failure.json"] = (
        ROOT / ".research/machine-annotation-integrity-stage-longpath-failure/failure-provenance.json").read_bytes()
    for name, value in members.items():
        require(not name.startswith("/") and "\\" not in name and ".." not in Path(name).parts
                and ".env" not in Path(name).parts, "Unsafe or private proof member")
        scan(value)
    manifest = {"schema_version": 1, "purpose": "machine_annotation_mechanical_stage_backup",
                "scientific_validity": "not_assessed", "review": "not_requested", "E0": "not_passed",
                "graph_snapshot_hash": graph,
                "members": [{"path": name, "sha256": sha(value), "bytes": len(value)} for name, value in sorted(members.items())]}
    manifest_bytes = canonical(manifest)
    scan(manifest_bytes)
    archive_path = ROOT / "evidence/episteme-machine-annotation-2026-11-08.zip"
    require(not archive_path.exists(), "Proof ZIP must be a new file")
    with zipfile.ZipFile(archive_path, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, value in sorted(members.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 8, 0, 0, 0))
            info.compress_type, info.external_attr = zipfile.ZIP_DEFLATED, 0o100644 << 16
            archive.writestr(info, value)
        archive.writestr("manifest.json", manifest_bytes)
    with zipfile.ZipFile(archive_path) as archive:
        require(len(archive.infolist()) == len(members) + 1 and set(archive.namelist()) == set(members) | {"manifest.json"},
                "Proof ZIP roster differs")
        require(archive.read("manifest.json") == manifest_bytes, "Proof ZIP internal manifest differs")
        for row in manifest["members"]:
            value = archive.read(row["path"])
            require(sha(value) == row["sha256"] and len(value) == row["bytes"], "Proof ZIP member differs")
    archive_proof = {"schema_version": 1, "path": archive_path.relative_to(ROOT).as_posix(),
        "sha256": sha(archive_path.read_bytes()), "bytes": archive_path.stat().st_size,
        "members": len(members) + 1, "uncompressed_member_bytes": sum(map(len, members.values())) + len(manifest_bytes),
        "all_members_sha256_and_size_verified": True, "configured_credential_and_common_encodings_scanned_in_memory": True,
        "graph_snapshot_hash": graph, "E0": "not_passed", "review": "not_requested", "scientific_validity": "not_assessed"}
    require(archive_proof["bytes"] < 95 * 1024 * 1024, "Proof ZIP exceeds publication limit")
    install_new(public / "episteme-archive-check.json", canonical(archive_proof))
    print(json.dumps({"stage": result["stage"], "artifacts": result["artifact_count"], "attempts": result["attempt_ledger"],
        "events": event_count, "receipts": receipt_count, "graph_snapshot_hash": graph,
        "restored_store_bytes": proof["restored_store_bytes"], "restored_files": proof["restore_files"],
        "stage_result_sha256": sha(stage_bytes), "archive": archive_proof, "E0": "not_passed"}, indent=2))


if __name__ == "__main__":
    main()
